#!/bin/bash

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Node.js is not installed. Installing..."
    curl -fsSL https://deb.nodesource.com/setup_14.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# Check if Puppeteer is installed
if ! npm list -g puppeteer &> /dev/null; then
    echo "Puppeteer is not installed. Installing..."
    npm install -g puppeteer
fi

echo "Node.js and Puppeteer are installed."

# Run the Puppeteer script from the separate file
node puppeteer_script.js
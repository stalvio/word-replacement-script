const puppeteer = require('puppeteer');
const { execSync } = require('child_process');
const os = require('os');

(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto('https://www.wix.com/studio/academy');  // Replace with the actual URL

    // Select all matching elements
    //const elements = await page.$$('li.wixui-horizontal-menu__item'); 
	// Select the first 'Course' element node based on its inner text using XPath
    const joinWaitlist = await page.evaluateHandle(() => {
        const xpath = '//span[text()="Join the waitlist"]';
        const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return result.singleNodeValue;
    });
	
		
	if (joinWaitlist) {
		const newTabPromise = new Promise(resolve => browser.once('targetcreated', resolve));
        await joinWaitlist.evaluate(b => b.click());
		
        // Wait for the new tab to open
        await newTabPromise;

        // Get the list of all pages and switch to the new tab
        const pages = await browser.pages();
        const newTab = pages[pages.length - 1];

        // Wait for a specific amount of time to ensure the page loads
        await newTab.waitForTimeout(2000);  // Adjust the wait time as needed

        // Get the URL of the new tab
        const newTabUrl = newTab.url();
		
		// Extract the substring starting from the last '=' character to the end of the URL
        const lastEqualsIndex = newTabUrl.lastIndexOf('=');
        const substring = lastEqualsIndex !== -1 ? newTabUrl.substring(lastEqualsIndex + 1) : '';
	
		// Copy the URL to the clipboard using system command (works on Windows and macOS)
        try {
            if (os.platform() === 'darwin') {
                execSync(`echo "${newTabUrl}" | pbcopy`); // macOS
            } else if (os.platform() === 'win32') {
                execSync(`echo ${newTabUrl} | clip`); // Windows
            }
            console.log('New Tab URL copied to clipboard:', newTabUrl);
        } catch (error) {
            console.error('Error copying URL to clipboard:', error);
        }
        
        // Log the URL 
        console.log('New Tab URL:', newTabUrl);
	} else {
		console.log("'Course' button not found or matched.");
	}
	// Check if elements were found

    await browser.close();
})();
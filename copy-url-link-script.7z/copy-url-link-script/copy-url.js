const clipboardy = import('clipboardy');

const newTabUrl = process.argv[2];

if (newTabUrl) {
    clipboardy.writeSync(newTabUrl);
    console.log('URL copied to clipboard:', newTabUrl);
} else {
    console.log('Usage: node copy-url.js <url>');
}